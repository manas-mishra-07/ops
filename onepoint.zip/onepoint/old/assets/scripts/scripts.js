if(AOS){
  AOS.init();
}

function toggleServiceCard(allowedCards){
  let servicesListSection = document.querySelectorAll('.servicesListSection .serviceSelection .serviceItem');
  servicesListSection.forEach((node, index) => {
    if(allowedCards > index){
      node.classList.remove('d-none')
      allServicesButtonWrapper.classList.add('d-none');
    } else {
      node.classList.add('d-none')
      allServicesButtonWrapper.classList.remove('d-none');
    }
  })
}

function toggleServicesList(){
  let allServicesButtonWrapper = document.querySelector('#allServicesButtonWrapper');
  let windowWidth = window.outerWidth;
  if(allServicesButtonWrapper){
    if(windowWidth >= 1200){
      toggleServiceCard(1000);
    }else if(windowWidth >= 992){
      toggleServiceCard(12);
    }else if(windowWidth >= 768){
      toggleServiceCard(10);
    }else{
      toggleServiceCard(8);
    }
  }
}

let new_scroll_position = 0;
let last_scroll_position;
let mainMenu = document.querySelector(".mainMenu");
let navSearch = document.querySelector('.bottomBar--search');
let navLocation = document.querySelector('.bottomBar--location');
navSearch.style.display = 'none';
navLocation.style.display = 'none';

window.addEventListener('scroll', function(e) {
  last_scroll_position = window.scrollY;
  if (last_scroll_position > 80) {
    mainMenu.classList.add("menuScrolled");
    // Scrolling down
    if (new_scroll_position < last_scroll_position && last_scroll_position > 80) {
      navSearch.classList.remove("slideDown");
      navLocation.classList.remove("slideDown");
      navSearch.classList.add("slideUp");
      navLocation.classList.add("slideUp");
      
      // Scrolling up
    } else if (new_scroll_position > last_scroll_position) {
      navSearch.classList.remove("slideUp");
      navSearch.classList.add("slideDown");
      navLocation.classList.remove("slideUp");
      navLocation.classList.add("slideDown");
    }
  }else{
    mainMenu.classList.remove("menuScrolled");
  }
  
  new_scroll_position = last_scroll_position;
});

// Start -- Sticky AppOffer
function bodyMenuPadding(){
  if(window.outerWidth < 768){
    document.body.style.paddingTop = mainMenu.offsetHeight + 'px';
  }else{
    document.body.style.paddingTop = 0;
    if(window.location.pathname.includes('cart')){
      mainMenu.classList.add("bg-warning");
      document.body.style.paddingTop = mainMenu.offsetHeight + 'px';
    }
  }
}
// End -- Sticky AppOffer

// Start -- Sticky AppOffer
function manageAppOfferModal(){
  if(window.outerWidth < 768 && (window.localStorage.getItem('appOfferModalAllowed') === null || window.localStorage.getItem('appOfferModalAllowed') == 'true')){
    openAppOfferModal();
  }else{
    closeAppOfferModal();
  }
}

function openAppOfferModal(){
  window.localStorage.setItem('appOfferModalAllowed',true);
  document.body.classList.add('appOfferOpened');
  document.querySelector('.appOffer').classList.add('open');
  document.querySelector('footer').style.paddingBottom = document.querySelector('.appOfferContent').offsetHeight + "px";
}

function closeAppOfferModal(targetType){
  document.querySelector('footer').style.paddingBottom = 0;
  document.body.classList.remove('appOfferOpened');
  document.querySelector('.appOffer').classList.remove('open');
  if(window.outerWidth < 768 && targetType){
    window.localStorage.setItem('appOfferModalAllowed',false);
  }
}
// End -- Sticky AppOffer

// Start -- Stats Counter
const counters = document.querySelectorAll('.counter');
counters.forEach(counter => {
  // function to increment the counter
  const onView = counter.getAttribute('data-aos-offset');
  function updateCount() {
    const targetSuffix = counter.getAttribute('data-suffix');
    const target = +counter.getAttribute('data-count');
    const count = +counter.innerHTML;

    const inc = Math.floor((target - count) / 100);

    if (count < target && inc > 0) {
      counter.innerHTML = (count + inc);
      // repeat the function
      setTimeout(updateCount, 10);
    }
    // if the count not equal to target, then add remaining count
    else if(targetSuffix){
      counter.innerHTML = target + targetSuffix;
    }else{
      counter.innerHTML = target + targetSuffix;
    }
  }
  if(!onView){
    updateCount();
  }else{
    let alreadyInitiated = false;
    if(!alreadyInitiated){
      setInterval(function(){
        if(counter.classList.contains('aos-animate') && !alreadyInitiated){
          console.log('initiate')
          updateCount();
          alreadyInitiated = true;
        }
      },100)
    }
  }
});
// End -- Stats Counter

function updateFaq(){
  if(document.querySelector('.faqSection')){
    let secondColAccordion = document.querySelectorAll('.faqSection .col-md-6')[1];
    if(secondColAccordion){
      if(window.outerWidth < 768){
        secondColAccordion.querySelector('.accordion-button').classList.add('collapsed');
        secondColAccordion.querySelector('.accordion-collapse').classList.remove('show');
        }else{
          secondColAccordion.querySelector('.accordion-button').classList.remove('collapsed');
          secondColAccordion.querySelector('.accordion-collapse').classList.add('show');
      }
    }
  }
}

function goBack(event){
  event.preventDefault();
  window.history.back();
}

function activateTooltips(){
  let tooltips = [...document.querySelectorAll('[data-bs-toggle="tooltip"]')];
  if(tooltips.length){
    tooltips.forEach(el => new bootstrap.Tooltip(el))
  }
}

function activatePopovers(){
  let popovers = [...document.querySelectorAll('[data-bs-toggle="popover"]')];
  if(popovers.length){
    popovers.forEach(el => new bootstrap.Popover(el))
  }
}

window.addEventListener("load", (event) => {
  bodyMenuPadding();
  manageAppOfferModal();
  updateFaq();
  toggleServicesList();
  activateTooltips();
  activatePopovers();
});

window.addEventListener('resize', function(){
  bodyMenuPadding();
  manageAppOfferModal();
  toggleServicesList();
  updateFaq();
  activateTooltips();
  activatePopovers();
})
