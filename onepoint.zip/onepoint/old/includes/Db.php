<?php 
require_once 'config.php';
class Db{
  protected $conn;
  public function __construct(){
      $this->conn=mysqli_connect(server,user,password,database) or die('Database Connection Failed');
  }
}
?>