<?php
require 'Db.php';
class Query extends Db{
    public function select($table){
       $sql="select * from $table";
       $execute=mysqli_query($this->conn,$sql);
       $result=[];
       while($record=mysqli_fetch_assoc($execute)){
               array_push($result,$record);
       }
       return $result;
    }
 public function get_services($id){
    $sql="select services.Id,services.Name,services.DisplayPriority,services.ServiceUrl,location_services.url,location_services.title from services inner Join location_services on services.id=location_services.service where location_services.CityId=$id and location_services.featured='1' and location_services.status='1' order by services.DisplayPriority ASC;";
    //$sql="Select * from location_services WHERE status='1' AND CityId=$id AND featured='1' ORDER BY service_position ASC";
    $exe=mysqli_query($this->conn,$sql);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
         array_push($result,$record);
         //create sub service file
         $subservice_file=$record['url'].'.html';
         if(!file_exists('city-service/'.$subservice_file)){
            fopen('city-service/'.$subservice_file,'w');
            copy('service.html','city-service/'.$subservice_file);
         }
     }
     return $result;
 }
 public function get_where($table,$array){
     $where='';
     foreach($array as $key=>$val){
          $where.=$key.'="'.$val.'" and ';
     }
     $where=rtrim($where,' and');
     $sql="select * from $table where $where";
      $exe=mysqli_query($this->conn,$sql);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
          array_push($result,$record);
     }
     return $result;
 }
}
?>