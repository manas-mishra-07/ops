<?php
define('BASE_URL','https://desvel.com/onepoint/');
define('server','localhost');
define('user','desvelco_onepoint');
define('password','0mZS$7G2@4##');
define('database','desvelco_newonepoint');
?>