<?php
error_reporting(E_ALL);
ini_set('display_error','1');
require 'autoload.php';
$db=new Query();
$html=new CreateHtml();
if(isset($_POST['sid'])){
    $faqdata=$db->get_reviews('reviews',$_POST['sid'],'ASC',8);
    $html->create_json('reviews.json',$faqdata);
}
?>